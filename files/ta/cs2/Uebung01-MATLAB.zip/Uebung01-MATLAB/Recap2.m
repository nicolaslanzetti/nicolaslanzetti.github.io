%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              RT2 Assistenz
%             Nicolas Lanzetti
%                05.03.2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all
clc

% FREQUENCY DOMAIN

s = tf('s');

P = 1/((s+1)*(s+2));
C = 4/(s+1);

L = series(P,C);
T = feedback(L,1);

[gamma,phi,wgamma,wc] = margin(L);

figure(1)
margin(L)
legend('L(j\cdot w)')

figure(2)
subplot(1,2,1)
bode(P,C,L)
legend('P(j\cdot w)','C(j\cdot w)','L(j\cdot w)')

subplot(1,2,2)
nyquist(P,L)
legend('P(j\cdot w)','L(j\cdot w)')

figure(3)
subplot(1,2,1)
step(L,T)
legend('Step response (open loop)', 'Step response (closed loop)')

subplot(1,2,2)
impulse(L,T)
legend('Impulse response (open loop)', 'Impulse response (closed loop)')