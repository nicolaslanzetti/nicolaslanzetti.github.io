%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              RT2 Assistenz
%             Nicolas Lanzetti
%                05.03.2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all
clc

s = tf('s');

P1 = 1/(s-2);
P2 = 2/((s-2))^2;

C1 = 4;
C2 = 4*(s+1)/(s/100+1);

% C1 = 4;
% C2 = 4*(s+1);

L1 = series(C1,P1);
L2 = series(C2,P2);

figure(1)
nyquist(P1,L1)


figure(2)
nyquist(P2,L2)
