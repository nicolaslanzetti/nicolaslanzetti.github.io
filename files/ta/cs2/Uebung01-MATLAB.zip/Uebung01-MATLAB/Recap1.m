%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              RT2 Assistenz
%             Nicolas Lanzetti
%                05.03.2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all
clc

% SYSTEM ANALYSIS

A = [1 2 3; 2 1 3; 0 1 3];
b = [1; 2; 0];
c = [1 0 3];
d = 0;

% Lyapunov Stability
disp('The eigenvalues of A are')
ev = eig(A)

% Controllability 
R = ctrb(A,b); % R = ctrb(ss(A,b,c,d));
if rank(R) == size(R,1)
    disp('The system is controllable.')
else 
    disp('The system is not controllable.')
end

% Observability
O = obsv(A,c); % Equivalent: O = obsv(ss(A,b,c,d));
if rank(O) == size(O,1)
    disp('The system is obsverable.')
else 
    disp('The system is not observable.')
end

% Transfer function
P = tf(ss(A,b,c,d));
P = minreal(P);

disp('The poles of P are')
p = pole(P)
disp('The zeros of P are')
z = zero(P)

figure(1)
pzmap(P)