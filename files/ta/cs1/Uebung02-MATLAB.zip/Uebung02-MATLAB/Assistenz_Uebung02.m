%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               RT1 Assitenz
%                 Uebung 1
%             Nicolas Lanzetti
%                01.10.2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clc;


% Definition der Matrizen des Systems
A = [ 1 2; -3 -1];
b = [0; 2];
c = [0 1];
d = 0;

% Simulation
sim('Assistenz_Uebung02_Modell');

% Plot
figure(1)
title('Block diagram')
plot(t,y_block)
hold on
plot(t,y_state,t,r,':')
legend('y_{block}(t)','y_{state}(t)','u(t)')
ylabel('y [-]')
xlabel('t [s]')
ylim([-2 2])