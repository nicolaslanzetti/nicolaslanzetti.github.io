function [] = rtplot(sys,a)


figure(a)
subplot(2,2,1)
for ii = 1:max(size(sys))
    step(sys(ii))
    hold on
end

subplot(2,2,2)
for ii = 1:max(size(sys))
    impulse(sys(ii))
    hold on
end

subplot(2,2,[3,4])
for ii = 1:max(size(sys))
    pzmap(sys(ii))
    hold on
    xlim([-2,2])
    ylim([-2,2])
end
end

