%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               RT1 Assistenz
%                 Uebung 3
%             Nicolas Lanzetti
%                30.10.2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all;
clear all;
clc;

s = tf('s');

% Nicht minimalphasige Nullstelle 
sys1 = zpk(1,[-1+j -1-j],-2);
sys2 = zpk(1.5,[-1+j -1-j],-2/1.5);

% Minimalphasige Nullstelle 
sys3 = zpk(-1,[-1+j -1-j],2);
sys4 = zpk(-1.5,[-1+j -1-j],2/1.5);

% Keine Nullstelle
sys5 = zpk([],[-1+j -1-j],2);
sys6 = zpk([],[-1+2j -1-2j],5);
sys7 = zpk([],[-1.5 -0.5],0.75);

% Plot (siehe Fuktion rtplot.m
rtplot([sys1 sys3 sys5],1)
%rtplot([sys1 sys2],2)
%rtplot([sys3 sys4],3)
%rtplot([sys5 sys6 sys7],4)
