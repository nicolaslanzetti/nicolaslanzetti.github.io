%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               RT1 Assitenz
%                 Uebung 3
%             Nicolas Lanzetti
%                01.10.2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear all;
clc;

% Parameter des Modells
k  = 0.1;

% GGW
ve = 10;
z1e = sqrt(ve/k);
z2e = 0;
we = 0;

% Parameter der Normierung
z10 = 10;
z20 = 10;
w0 = 10;
v0 = 10;

% GGW nach der Normierung
ue = ve/v0;
x1e = z1e/z10;
x2e = z2e/z20;
ye = we/w0;

% Definition der Matrizen des linearisierten Systems
A = [ 0 z20/z10; -2*k*z10^2/z20*x1e 0];
b = [0; v0/z20];
c = [0 z20/w0];
d = 0;

% Anfangsbedinungen
z1IC = z1e;
z2IC = z2e;
xIC = [0 0];

% Simulation (f�r 20 Sekunden)
sim('Assistenz_Uebung03_Modell',20);

% Plot
figure(1)
plot(t,ynlin,t,ylin1,t,ylin2,'--')
legend('w_{nonlin}(t)','w_{lin1}(t)','w_{lin2}(t)')
ylabel('w [-]')
xlabel('t [s]')
title('Output of the system z_{2} (Note: z_{1} is not plotted!)')