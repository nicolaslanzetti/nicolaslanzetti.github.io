close all
clear all
clc

% Parameters
mCrane = 1e6;
mPot   = 10e3;
fMax   = 1000000;
tMax   = 1000000;
c1     = 10;
c2     = 10;
cr     = 0.01;
rho    = 0.7;
A      = 1;
cw     = 1;
beta   = 0;
Theta  = 0.1;
g      = 9.81;

% Initial conditions
v0     = 0;
omega0 = 0;
s0     = 10;

% Simulate
sim('exercise02.slx',20)

% Plot
ax(1) = subplot(4,1,1);
plot(time,v,'b')
grid on
ylabel('$v$')

ax(2) = subplot(4,1,2);
plot(time,phi1,'b')
grid on
ylabel('$\phi_1$')

ax(3) = subplot(4,1,3);
plot(time,omega,'b')
grid on
ylabel('$\omega$')

ax(4) = subplot(4,1,4);
plot(time,phi2,'b')
grid on
ylabel('$\phi_2$')
xlabel('Time')

for i = 1:length(ax)
    ax(i).FontSize = 16;
    ax(i).YLabel.Interpreter   = 'Latex';
    ax(i).XLabel.Interpreter   = 'Latex';
    ax(i).TickLabelInterpreter = 'Latex';
end