close all
clear all
clc

% Parameters
mCrane = 1e6;
mPot   = 10e3;
fMax   = 1000000;
tMax   = 1000000;
c1     = 10;
c2     = 10;
cr     = 0.01;
rho    = 0.7;
A      = 1;
cw     = 1;
beta   = 0;
Theta  = 0.1;
g      = 9.81;
% Function for drag coefficient: cw(omega) = cw + abs(sin(omega))

% Initial conditions
v0     = 0;
omega0 = 0;
s0     = 10;

% Simulate
sim('exercise02.slx',20)

%% Plots
figure('Name','Plots')
ax(1) = subplot(4,1,1);
plot(time,v,'b')
grid on
ylabel('$v$')

ax(2) = subplot(4,1,2);
plot(time,phi1,'b')
grid on
ylabel('$\phi_1$')

ax(3) = subplot(4,1,3);
plot(time,omega,'b')
grid on
ylabel('$\omega$')

ax(4) = subplot(4,1,4);
plot(time,phi2,'b')
grid on
ylabel('$\phi_2$')
xlabel('Time')

for i = 1:length(ax)
    ax(i).FontSize = 16;
    ax(i).YLabel.Interpreter   = 'Latex';
    ax(i).XLabel.Interpreter   = 'Latex';
    ax(i).TickLabelInterpreter = 'Latex';
end

figure('Name','Simulation')
x   = 0;
phi = 0;
R   = 20;
H   = 20;
b   = 30;
h   = 20;
for i = 1:length(time)-1
    x   = x + v(i)*(time(i+1)-time(i));
    phi = phi + omega(i)*(time(i+1)-time(i));
    phi = mod(rad2deg(phi),360);
    
    clf
    hold on
    plot3([x x],[0 0],[0 H],'k','linewidth',5)
    plot3([x x+R*cos(phi)],[0 R*sin(phi)],[H H],'k','linewidth',5)
    plot3([x+s(i)*cos(phi) x+s(i)*cos(phi)],[s(i)*sin(phi) s(i)*sin(phi)],[H H/2],'r','linewidth',1)
    plot3(x+(-R:0.1:R),+sqrt(R^2-(-R:0.1:R).^2),H*ones(size(-R:0.1:R)),'k:')
    plot3(x+(-R:0.1:R),-sqrt(R^2-(-R:0.1:R).^2),H*ones(size(-R:0.1:R)),'k:')
    scatter3(x,0,H,30,'k','filled')
    scatter3(x+R*cos(phi),R*sin(phi),H,30,'k','filled')
    scatter3(x+s(i)*cos(phi),s(i)*sin(phi),H/2,50,'r','filled')
    rectangle('Position',[x-b/2,-h/2,b,h],'FaceColor','k','EdgeColor','k')
    grid on
    xlim([-R 100+R])
    ylim([-R-50 50+R])
    zlim([0 1.1*H])
    view(3)
    
    set(gca,'FontSize',16)
    set(gca,'TickLabelInterpreter','Latex')
    
    pause(0.5)
end